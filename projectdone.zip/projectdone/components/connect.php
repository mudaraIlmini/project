<?php

$db_name = 'mysql:host=localhost:3307;dbname=shop_db';'root';'';
$user_name = 'root';
$user_password = '';

$conn = new PDO($db_name, $user_name, $user_password);


?>