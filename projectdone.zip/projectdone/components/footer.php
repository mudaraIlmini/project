<footer class="footer">

   <section class="grid">

      <div class="box">
         <h3>Quick links</h3>
         <a href="home.php"> <i class="fas fa-angle-right"></i> Home</a>
         <a href="about.php"> <i class="fas fa-angle-right"></i> About</a>
         <a href="shop.php"> <i class="fas fa-angle-right"></i> Shop</a>
         <a href="contact.php"> <i class="fas fa-angle-right"></i> Contact</a>
      </div>

      <div class="box">
         <h3>Extra links</h3>
         <a href="user_login.php"> <i class="fas fa-angle-right"></i> Login</a>
         <a href="user_register.php"> <i class="fas fa-angle-right"></i> Register</a>
         <a href="cart.php"> <i class="fas fa-angle-right"></i> Cart</a>
         <a href="orders.php"> <i class="fas fa-angle-right"></i> Orders</a>
      </div>

      <div class="box">
         <h3>Contact Us.</h3>
         <a href="tel:759337610"><i class="fas fa-phone"></i> +94 759337610</a>
         <a href="tel:723649215"><i class="fas fa-phone"></i> +94 723649215</a>
         <a href="m.i.dassanayake@gmail.com"><i class="fas fa-envelope"></i> m.i.dassanayake@gmail.com</a>
         <a href="https://www.google.lk/maps/place/Kandy/@7.2946286,80.5845814,13z/data=!3m1!4b1!4m6!3m5!1s0x3ae366266498acd3:0x411a3818a1e03c35!8m2!3d7.2905715!4d80.6337262!16zL20vMDFzZzRf?entry=ttu&g_ep=EgoyMDI0MTExMy4xIKXMDSoASAFQAw%3D%3Dt"><i class="fas fa-map-marker-alt"></i> Kandy, Sri Lanka </a>
      </div>

      <div class="box">
         <h3>Follow Us</h3>
         <a href="https://www.bing.com/ck/a?!&&p=cf1718da6244d987abb699f4a73d8c9a6940b0031584596b4c40450c4cb4f41eJmltdHM9MTczMTg4ODAwMA&ptn=3&ver=2&hsh=4&fclid=28602962-1bd9-6fe7-2a76-3acc1a0c6eea&psq=www.facebook.com+log+in&u=a1aHR0cHM6Ly93d3cuZmFjZWJvb2suY29tL2xvZ2luLnBocC8&ntb=1" target="_blank"><i class="fab fa-facebook-f"></i>facebook</a>
         <a href="https://www.bing.com/ck/a?!&&p=b4def42d7fde33df1eabb5d70e6794e384403b9a8d1fcd2e7c6661005d1f4db6JmltdHM9MTczMTg4ODAwMA&ptn=3&ver=2&hsh=4&fclid=28602962-1bd9-6fe7-2a76-3acc1a0c6eea&psq=www.twitter.com+log+in&u=a1aHR0cHM6Ly90d2l0dGVyLmNvbS9sb2dpbg&ntb=1" target="_blank"><i class="fab fa-twitter"></i>Twitter</a>
         <a href="https://www.bing.com/ck/a?!&&p=9208df0f26d24fee28c427639a760fd6eb829748ccca8f7da6267916a672caa4JmltdHM9MTczMTg4ODAwMA&ptn=3&ver=2&hsh=4&fclid=28602962-1bd9-6fe7-2a76-3acc1a0c6eea&psq=www.instergram.com+log+in&u=a1aHR0cHM6Ly93d3cuaW5zdGFncmFtLmNvbS9hY2NvdW50cy9sb2dpbi8&ntb=1" target="_blank"><i class="fab fa-instagram"></i>Instagram</a>
         <a href="https://www.bing.com/ck/a?!&&p=930c8d6eafcb02ecf0b8a8a553cf08fd268636f7e905adf830f0766b4ce87abeJmltdHM9MTczMTg4ODAwMA&ptn=3&ver=2&hsh=4&fclid=28602962-1bd9-6fe7-2a76-3acc1a0c6eea&psq=www.linkdin.com+log+in&u=a1aHR0cHM6Ly93d3cubGlua2VkaW4uY29tL2xvZ2lu&ntb=1" target="_blank"><i class="fab fa-linkedin"></i>Linkedin</a>
      </div>

   </section>

   <div class="credit">&copy; copyright @ <?= date('Y'); ?> by <span>MUDARA DASSANAYAKE</span> | all rights reserved!</div>

</footer>